import BeautySDK
import CoreImage
import ImageIO
import XCTest
@testable import BeautyDemo

@MainActor
final class ImageEditorPipelineTests: XCTestCase {
    func testPIPE04FixtureInputProcessesThroughPublicSDKImagePath() async throws {
        let pipeline = ImageEditorPipeline()
        let parameters = BeautyParameters(skinSmoothing: 0.35)

        pipeline.process(
            input: .fixture(id: "fixture", image: Self.testImage(red: 0.2)),
            parameters: parameters
        )
        await pipeline.waitUntilIdle()

        let snapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(snapshot.sourceKind, .fixture)
        XCTAssertEqual(snapshot.sourceID, "fixture")
        XCTAssertEqual(snapshot.orientation, .up)
        XCTAssertEqual(snapshot.metadata.source, .photo)
        XCTAssertFalse(snapshot.metadata.isInputMirrored)
        XCTAssertFalse(snapshot.metadata.isPreviewMirrored)
        XCTAssertNil(snapshot.metadata.timestamp)
        XCTAssertEqual(snapshot.parameters, parameters)
        XCTAssertEqual(snapshot.outputImage.extent, snapshot.inputImage.extent)
        XCTAssertEqual(snapshot.outputCGImage.width, 2)
        XCTAssertEqual(snapshot.outputCGImage.height, 2)
    }

    func testPIPE04PhotosPickerDataSeamUsesDecodedImageAndProcessor() async throws {
        let records = LockedPhotoValues<ImageInputKind>()
        let decoder = ImageInputDecoder { source in
            records.append(source.kind)
            return DecodedImageInput(
                source: source,
                image: Self.testImage(red: 0.4),
                metadata: source.metadata
            )
        }
        let processor = StillImageProcessor { image, _, _ in
            BeautyResult(output: image, detectionSummary: .notRun)
        }
        let pipeline = ImageEditorPipeline(decoder: decoder, processor: processor)

        pipeline.process(
            input: .photosPickerData(Data([1, 2, 3]), id: "picker-data"),
            parameters: .init(skinSmoothing: 0.2)
        )
        await pipeline.waitUntilIdle()

        let snapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(records.values, [.photosPickerData])
        XCTAssertEqual(snapshot.sourceKind, .photosPickerData)
        XCTAssertEqual(snapshot.sourceID, "picker-data")
        XCTAssertEqual(snapshot.metadata.source, .photo)
        XCTAssertEqual(snapshot.detectionSummary, .notRun)
    }

    func testInputByteLimitAllowsExactDataAndRejectsOneByteOverBeforeDecodeThenRecovers() async throws {
        let decodedKinds = LockedPhotoValues<ImageInputKind>()
        let decoder = ImageInputDecoder { source in
            decodedKinds.append(source.kind)
            return DecodedImageInput(
                source: source,
                image: Self.testImage(red: 0.4),
                metadata: source.metadata
            )
        }
        let processor = StillImageProcessor { image, _, _ in
            BeautyResult(output: image)
        }
        let pipeline = ImageEditorPipeline(
            configuration: BeautyConfiguration(
                maximumInputByteCount: 3,
                maximumInputPixelCount: 4
            ),
            decoder: decoder,
            processor: processor
        )

        pipeline.process(input: .photosPickerData(Data([1, 2, 3]), id: "exact"), parameters: .init())
        await pipeline.waitUntilIdle()
        let exactSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(exactSnapshot.sourceID, "exact")
        XCTAssertEqual(decodedKinds.values, [.photosPickerData])

        pipeline.process(input: .photosPickerData(Data([1, 2, 3, 4]), id: "oversized"), parameters: .init())

        XCTAssertEqual(pipeline.state.latestSnapshot, exactSnapshot)
        XCTAssertEqual(pipeline.state.statusText, PhotoProcessingState.decodeFailureText)
        XCTAssertEqual(decodedKinds.values, [.photosPickerData])
        await pipeline.waitUntilIdle()

        pipeline.process(input: .fixture(id: "recovered", image: Self.testImage(red: 0.8)), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state.latestSnapshot?.sourceID, "recovered")
        XCTAssertNil(pipeline.state.statusText)
        XCTAssertEqual(decodedKinds.values, [.photosPickerData, .fixture])
    }

    func testInputPixelLimitAllowsExactExtentAndRejectsOnePixelOverBeforeProcessOrRender() async throws {
        let processorCalls = LockedPhotoCounter()
        let renderCalls = LockedPhotoCounter()
        let decoder = ImageInputDecoder { source in
            let image = source.id == "oversized"
                ? Self.testImage(width: 5, height: 1, red: 0.7)
                : Self.testImage(width: 2, height: 2, red: 0.3)
            return DecodedImageInput(source: source, image: image, metadata: source.metadata)
        }
        let processor = StillImageProcessor { image, _, _ in
            _ = processorCalls.increment()
            return BeautyResult(output: image)
        }
        let renderer = ImageDisplayRenderer { image in
            _ = renderCalls.increment()
            return try Self.render(image)
        }
        let pipeline = ImageEditorPipeline(
            configuration: BeautyConfiguration(
                maximumInputByteCount: 8,
                maximumInputPixelCount: 4
            ),
            decoder: decoder,
            processor: processor,
            renderer: renderer
        )

        pipeline.process(input: .photosPickerData(Data([1]), id: "exact"), parameters: .init())
        await pipeline.waitUntilIdle()
        let exactSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(processorCalls.current, 1)
        XCTAssertEqual(renderCalls.current, 2)

        pipeline.process(input: .photosPickerData(Data([2]), id: "oversized"), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state.latestSnapshot, exactSnapshot)
        XCTAssertEqual(pipeline.state.statusText, PhotoProcessingState.decodeFailureText)
        XCTAssertEqual(processorCalls.current, 1)
        XCTAssertEqual(renderCalls.current, 2)

        pipeline.process(input: .fixture(id: "recovered", image: Self.testImage(red: 0.9)), parameters: .init())
        await pipeline.waitUntilIdle()
        XCTAssertEqual(pipeline.state.latestSnapshot?.sourceID, "recovered")
        XCTAssertEqual(processorCalls.current, 2)
        XCTAssertEqual(renderCalls.current, 4)
    }

    func testStaleOversizedDecodedSelectionCannotReplaceLatestSuccess() async throws {
        let staleStarted = expectation(description: "stale decode started")
        let releaseStale = DispatchSemaphore(value: 0)
        let processorCalls = LockedPhotoCounter()
        let decoder = ImageInputDecoder { source in
            if source.id == "stale-oversized" {
                staleStarted.fulfill()
                _ = releaseStale.wait(timeout: .now() + 2)
                return DecodedImageInput(
                    source: source,
                    image: Self.testImage(width: 5, height: 1, red: 0.1),
                    metadata: source.metadata
                )
            }
            return DecodedImageInput(
                source: source,
                image: Self.testImage(red: 0.9),
                metadata: source.metadata
            )
        }
        let processor = StillImageProcessor { image, _, _ in
            _ = processorCalls.increment()
            return BeautyResult(output: image)
        }
        let pipeline = ImageEditorPipeline(
            configuration: BeautyConfiguration(maximumInputPixelCount: 4),
            decoder: decoder,
            processor: processor,
            processingQueue: DispatchQueue(
                label: "beauty.demo.tests.concurrent-input-bounds",
                attributes: .concurrent
            )
        )

        pipeline.process(
            input: .photosPickerData(Data([1]), id: "stale-oversized"),
            parameters: .init()
        )
        await fulfillment(of: [staleStarted], timeout: 2)
        pipeline.process(input: .fixture(id: "latest-valid"), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state.latestSnapshot?.sourceID, "latest-valid")
        releaseStale.signal()
        try await Task.sleep(for: .milliseconds(50))

        XCTAssertEqual(pipeline.state.latestSnapshot?.sourceID, "latest-valid")
        XCTAssertNil(pipeline.state.statusText)
        XCTAssertEqual(processorCalls.current, 1)
    }

    func testD08CancellationIsNoopAndShowsNoError() async throws {
        let pipeline = ImageEditorPipeline()
        pipeline.process(input: .fixture(id: "existing", image: Self.testImage(red: 0.1)), parameters: .init())
        await pipeline.waitUntilIdle()
        let previousState = pipeline.state

        pipeline.process(input: .cancelled, parameters: .init(skinSmoothing: 1))
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state, previousState)
        XCTAssertNil(pipeline.state.statusText)
    }

    func testD08D12D13DecodeFailurePreservesPreviousVisualAndUsesFriendlyCopy() async throws {
        let pipeline = ImageEditorPipeline()
        pipeline.process(input: .fixture(id: "existing", image: Self.testImage(red: 0.1)), parameters: .init())
        await pipeline.waitUntilIdle()
        let previousSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)

        pipeline.process(input: .photosPickerData(Data()), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state.latestSnapshot, previousSnapshot)
        XCTAssertEqual(pipeline.state.statusText, PhotoProcessingState.decodeFailureText)
        XCTAssertFalse(pipeline.state.statusText?.contains("NSError") == true)
        XCTAssertFalse(pipeline.state.statusText?.contains("invalidInput") == true)
        XCTAssertFalse(pipeline.state.statusText?.contains("/") == true)
    }

    func testPERF03SelectionFailureCanRecoverWithLatestValidFixture() async throws {
        let pipeline = ImageEditorPipeline()
        pipeline.process(
            input: .fixture(id: "initial-valid", image: Self.testImage(red: 0.2)),
            parameters: .init(skinSmoothing: 0.2)
        )
        await pipeline.waitUntilIdle()
        let previousSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)

        pipeline.process(input: .photosPickerData(Data()), parameters: .init(skinSmoothing: 0.9))
        await pipeline.waitUntilIdle()

        XCTAssertEqual(pipeline.state.latestSnapshot, previousSnapshot)
        XCTAssertEqual(pipeline.state.statusText, PhotoProcessingState.decodeFailureText)
        XCTAssertFalse(pipeline.state.statusText?.contains("NSError") == true)
        XCTAssertFalse(pipeline.state.statusText?.contains("/") == true)

        // PERF-03: after selection failure, the latest valid fixture replaces stale failure state.
        pipeline.process(
            input: .fixture(id: "latest-valid", image: Self.testImage(red: 0.8)),
            parameters: .init(skinSmoothing: 0.7)
        )
        await pipeline.waitUntilIdle()

        let recoveredSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(recoveredSnapshot.sourceID, "latest-valid")
        XCTAssertEqual(recoveredSnapshot.parameters.skinSmoothing, 0.7)
        XCTAssertNil(pipeline.state.statusText)
        XCTAssertNotEqual(recoveredSnapshot, previousSnapshot)
    }

    func testD11LoadingOverlaysPreviousVisual() async throws {
        let secondStarted = expectation(description: "second photo processing started")
        let releaseSecond = DispatchSemaphore(value: 0)
        let callCount = LockedPhotoCounter()
        let processor = StillImageProcessor { image, _, _ in
            if callCount.increment() == 2 {
                secondStarted.fulfill()
                _ = releaseSecond.wait(timeout: .now() + 2)
            }
            return BeautyResult(output: image)
        }
        let pipeline = ImageEditorPipeline(processor: processor)

        pipeline.process(input: .fixture(id: "first", image: Self.testImage(red: 0.2)), parameters: .init())
        await pipeline.waitUntilIdle()
        let previousSnapshot = try XCTUnwrap(pipeline.state.latestSnapshot)

        pipeline.process(input: .fixture(id: "second", image: Self.testImage(red: 0.7)), parameters: .init())
        await fulfillment(of: [secondStarted], timeout: 2)

        XCTAssertEqual(pipeline.state, .loading(previousSnapshot: previousSnapshot))
        XCTAssertEqual(pipeline.state.statusText, "Processing photo...")

        releaseSecond.signal()
        await pipeline.waitUntilIdle()
    }

    func testD14StalePhotoWorkIsIgnoredInFavorOfLatestParameters() async throws {
        let processor = StillImageProcessor { image, _, _ in
            BeautyResult(output: image)
        }
        let pipeline = ImageEditorPipeline(processor: processor)

        pipeline.process(
            input: .fixture(id: "stale", image: Self.testImage(red: 0.1)),
            parameters: .init(skinSmoothing: 0.1)
        )
        pipeline.process(
            input: .fixture(id: "latest", image: Self.testImage(red: 0.9)),
            parameters: .init(skinSmoothing: 0.9)
        )
        await pipeline.waitUntilIdle()

        let snapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(snapshot.sourceID, "latest")
        XCTAssertEqual(snapshot.parameters.skinSmoothing, 0.9)
    }

    func testD14StalePhotoCompletionDoesNotBlockIdleWaitForLatestWork() async throws {
        let firstStarted = expectation(description: "first photo processing started")
        let releaseFirst = DispatchSemaphore(value: 0)
        let waitReturned = expectation(description: "waitUntilIdle returned after latest work")
        let callCount = LockedPhotoCounter()
        let processor = StillImageProcessor { image, _, _ in
            if callCount.increment() == 1 {
                firstStarted.fulfill()
                _ = releaseFirst.wait(timeout: .now() + 2)
            }
            return BeautyResult(output: image)
        }
        let pipeline = ImageEditorPipeline(
            processor: processor,
            processingQueue: DispatchQueue(label: "beauty.demo.tests.concurrent-photo-pipeline", attributes: .concurrent)
        )

        pipeline.process(
            input: .fixture(id: "stale", image: Self.testImage(red: 0.1)),
            parameters: .init(skinSmoothing: 0.1)
        )
        await fulfillment(of: [firstStarted], timeout: 2)
        pipeline.process(
            input: .fixture(id: "latest", image: Self.testImage(red: 0.9)),
            parameters: .init(skinSmoothing: 0.9)
        )

        Task { @MainActor in
            await pipeline.waitUntilIdle()
            waitReturned.fulfill()
        }
        await fulfillment(of: [waitReturned], timeout: 2)
        releaseFirst.signal()
        await pipeline.waitUntilIdle()

        let snapshot = try XCTUnwrap(pipeline.state.latestSnapshot)
        XCTAssertEqual(snapshot.sourceID, "latest")
        XCTAssertEqual(snapshot.parameters.skinSmoothing, 0.9)
    }

    func testPIPE07PhotoDetectionStatusPersistsUntilNewProcessingResult() async throws {
        let summaries = LockedPhotoQueue<BeautyDetectionSummary?>([
            BeautyDetectionSummary(
                availability: .partial,
                reasons: [.missingLandmarks],
                faceCount: 1,
                usedFaceCount: 0
            ),
            BeautyDetectionSummary(
                availability: .lowConfidence,
                reasons: [.lowConfidenceFace],
                faceCount: 1,
                usedFaceCount: 0
            )
        ])
        let processor = StillImageProcessor { image, _, _ in
            BeautyResult(output: image, detectionSummary: summaries.pop() ?? nil)
        }
        let pipeline = ImageEditorPipeline(processor: processor)

        pipeline.process(input: .fixture(id: "partial", image: Self.testImage(red: 0.2)), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(
            pipeline.state.statusText,
            "Face partly visible. Some face adjustments are softened."
        )
        XCTAssertEqual(pipeline.state.detectionDebugSummary?.reasonCodes, ["missingLandmarks"])

        pipeline.process(input: .fixture(id: "low", image: Self.testImage(red: 0.4)), parameters: .init())
        await pipeline.waitUntilIdle()

        XCTAssertEqual(
            pipeline.state.statusText,
            "Face detection is uncertain. Face adjustments are softened."
        )
        XCTAssertEqual(pipeline.state.detectionDebugSummary?.reasonCodes, ["lowConfidenceFace"])
    }

    nonisolated private static func testImage(red: CGFloat) -> CIImage {
        testImage(width: 2, height: 2, red: red)
    }

    nonisolated private static func testImage(width: CGFloat, height: CGFloat, red: CGFloat) -> CIImage {
        CIImage(color: CIColor(red: red, green: 0.3, blue: 0.6, alpha: 1))
            .cropped(to: CGRect(x: 0, y: 0, width: width, height: height))
    }

    nonisolated private static func render(_ image: CIImage) throws -> CGImage {
        let context = CIContext(options: [.workingColorSpace: CGColorSpaceCreateDeviceRGB()])
        guard let result = context.createCGImage(image, from: image.extent) else {
            throw BeautyError.invalidInput
        }
        return result
    }
}

nonisolated private final class LockedPhotoValues<Element>: @unchecked Sendable {
    private let queue = DispatchQueue(label: "beauty.demo.tests.locked-photo-values")
    private var storage: [Element] = []

    var values: [Element] {
        queue.sync { storage }
    }

    func append(_ element: Element) {
        queue.sync {
            storage.append(element)
        }
    }
}

nonisolated private final class LockedPhotoCounter: @unchecked Sendable {
    private let queue = DispatchQueue(label: "beauty.demo.tests.locked-photo-counter")
    private var value = 0

    func increment() -> Int {
        queue.sync {
            value += 1
            return value
        }
    }

    var current: Int {
        queue.sync { value }
    }
}

nonisolated private final class LockedPhotoQueue<Element>: @unchecked Sendable {
    private let queue = DispatchQueue(label: "beauty.demo.tests.locked-photo-queue")
    private var storage: [Element]

    init(_ storage: [Element]) {
        self.storage = storage
    }

    func pop() -> Element? {
        queue.sync {
            guard !storage.isEmpty else {
                return nil
            }
            return storage.removeFirst()
        }
    }
}
